function serialdisconnect(s)
    
    fclose(s)
    delete(s)
    clear s
